# Membuat APK Digital Stok RM

## Cara A - Otomatis lewat GitHub (tanpa Android Studio, gratis)
1. Buat akun di github.com, lalu buat repositori baru (Private juga boleh).
2. Unggah SEMUA isi folder ini ke repositori itu, termasuk folder `.github`
   (pastikan file `.github/workflows/build-apk.yml` ikut terunggah).
3. Buka tab **Actions** > **Build APK** > **Run workflow**. Tunggu sekitar 5-10 menit.
4. Setelah selesai (centang hijau), buka run tersebut, lalu unduh **DigitalStokRM-apk**
   di bagian Artifacts.
5. Ekstrak zip-nya, kirim `app-debug.apk` ke HP, lalu pasang
   (izinkan "Instal dari sumber tidak dikenal").

## Cara B - Android Studio (di komputer)
1. Pasang Node.js 20, JDK 17, dan Android Studio.
2. Di folder ini jalankan:
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
3. Di Android Studio: Build > Build APK(s).

## Mengubah isi aplikasi
Edit `www/index.html`, lalu build ulang (Cara A: unggah file terbaru, jalankan Build APK).

## Catatan
- Data tersimpan di dalam aplikasi (per HP). Menghapus data aplikasi atau uninstall akan menghapus isian.
- APK ini versi debug: cukup untuk dipakai sendiri atau dibagikan.
- Folder `www` juga siap dijadikan PWA bila di-hosting (HTTPS).
